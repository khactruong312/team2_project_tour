<?php
return [
    'host' => '127.0.0.1',
    'db' => 'tour_ops',
    'user' => 'root',
    'pass' => ''
];
