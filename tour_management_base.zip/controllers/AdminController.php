<?php
require_once __DIR__.'/../models/Tour.php';
class AdminController {
    public function dashboard() {
        $model = new Tour();
        $tours = $model->getAll();
        include __DIR__.'/../views/admin/dashboard.php';
    }
}
?>