<?php
// Simple router
$role = $_GET['role'] ?? 'admin';
$action = $_GET['action'] ?? 'dashboard';

if($role === 'admin') {
    require_once __DIR__.'/controllers/AdminController.php';
    $controller = new AdminController();
    if(method_exists($controller, $action)) $controller->$action();
    else echo 'Action not found';
} else {
    echo 'Role not supported yet';
}
?>