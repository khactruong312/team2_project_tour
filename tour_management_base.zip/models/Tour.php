<?php
require_once __DIR__.'/../core/BaseModel.php';
class Tour extends BaseModel {
    protected $table = 'tour';
}
?>