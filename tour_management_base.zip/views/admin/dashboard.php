<!DOCTYPE html>
<html lang='vi'>
<head><meta charset='UTF-8'><title>Admin Dashboard</title></head>
<body>
<h1>Danh sách Tour</h1>
<table border='1' cellpadding='5'>
<tr><th>ID</th><th>Mã</th><th>Tên tour</th></tr>
<?php foreach($tours as $t): ?>
<tr><td><?= $t['tour_id'] ?></td><td><?= $t['code'] ?></td><td><?= $t['name'] ?></td></tr>
<?php endforeach; ?>
</table>
</body></html>